---
title: "Principles of Malnutrition"
summary: "An overview of the causes and classifications of malnutrition."
---

# Principles of Malnutrition

This topic covers the primary and secondary forms of malnutrition in pediatrics.
